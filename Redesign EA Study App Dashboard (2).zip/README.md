
  # Redesign EA Study App Dashboard

  This is a code bundle for Redesign EA Study App Dashboard. The original project is available at https://www.figma.com/design/qSBAm2b7fcP6bZGDSH2fiB/Redesign-EA-Study-App-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  